import { APIRequestContext, expect } from "@playwright/test";
import { ArticleData } from "../test_data/article.data";

export class ArticleApi {

    constructor(private request: APIRequestContext) {}

    async createArticle(article: ArticleData) {

        const response = await this.request.post(
            "/api/articles",
            {
                data: {
                    article
                }
            }
        );

        expect(response.ok()).toBeTruthy();

        return await response.json();

    }

    async deleteArticle(slug: string) {

        const response = await this.request.delete(
            `https://conduit-api.bondaracademy.com/api/articles/${slug}`
        );

        expect(response.ok()).toBeTruthy();

    }

}