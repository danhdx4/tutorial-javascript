import { test } from "../fixtures/auth.fixture";
import { ArticleApi } from "../api/article.api";
import { ArticlePage } from "../pages/article.page";
import { articleData } from "../test_data/article.data";

let slug = "";

test.beforeEach(async ({ request }) => {

    const articleApi = new ArticleApi(request);

    const response = await articleApi.createArticle(articleData);

    slug = response.article.slug;

});

test("Delete Article", async ({ page }) => {

    const articlePage = new ArticlePage(page);

    await page.goto(`/article/${slug}`);

    await articlePage.deleteArticle();

});