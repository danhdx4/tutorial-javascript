import { test, expect } from "../fixtures/auth.fixture";
import { ArticlePage } from "../pages/article.page";
import { articleData } from "../test_data/article.data";
import { ArticleApi } from "../api/article.api";

let slug = "";

test.afterEach(async ({ request }) => {
  if (slug) {
    const articleApi = new ArticleApi(request);
    await articleApi.deleteArticle(slug);
  }
});

test("Create Article", async ({ page }) => {
  const articlePage = new ArticlePage(page);

  await articlePage.createArticle(
    articleData.title,
    articleData.description,
    articleData.body
  );

  await articlePage.verifyArticle(articleData.title);

  slug = page.url().split("/").pop()!;
});
