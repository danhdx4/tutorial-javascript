import { expect, Page as PlaywrightPage } from "@playwright/test";
import { Page } from "./base.page";
import { PageUrl } from "../untils/constants";

export class LoginPage extends Page {
  readonly pageUrl = PageUrl.LOGIN;

  constructor(page: PlaywrightPage) {
    super(page);
  }

  readonly emailTextbox = this.page.getByPlaceholder("Email");
  readonly passwordTextbox = this.page.getByPlaceholder("Password");
  readonly loginButton = this.page.getByRole("button", {
    name: "Sign in",
  });

  async goto(): Promise<void> {
    await this.page.goto(this.pageUrl);
  }

  async login(email: string, password: string): Promise<void> {
    await this.emailTextbox.fill(email);
    await this.passwordTextbox.fill(password);

    await Promise.all([
      this.page.waitForLoadState("networkidle"),
      this.loginButton.click(),
    ]);
  }

  async verifyLoginSuccess(): Promise<void> {
    await expect(this.page.getByText("Global Feed")).toBeVisible({ timeout: 10000 });
  }
}