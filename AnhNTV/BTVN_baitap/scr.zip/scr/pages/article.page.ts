import { expect, Page } from "@playwright/test";

export class ArticlePage {
  constructor(private page: Page) {}

  async createArticle(title: string, description: string, body: string) {
    await this.page.getByText("New Article").click();
    await this.page.getByPlaceholder("Article Title").fill(title);
    await this.page.getByPlaceholder("What's this article about?").fill(description);
    await this.page.getByPlaceholder("Write your article (in markdown)").fill(body);
    await this.page.getByRole("button", { name: "Publish Article" }).click();
  }

  async verifyArticle(title: string) {
    await expect(this.page.getByRole("heading", { name: title })).toBeVisible();
  }

  async deleteArticle() {
    await this.page.getByRole("button", { name: "Delete Article" }).click();
  }
}
